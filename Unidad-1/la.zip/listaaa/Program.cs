﻿using System;
using System.Collections.Generic;

class Program
{
    static double Promedio(List<double> lista)
    {
        if (lista.Count == 0)
            return 0;

        double suma = 0;
        foreach (double num in lista)
        {
            suma += num;
        }
        return suma / lista.Count;
    }

    static void Main(string[] args)
    {
        Console.WriteLine("Calcular Promedio de una Lista");
        Console.Write("¿Cuántos números vas a ingresar? ");
        int cantidad = Convert.ToInt32(Console.ReadLine());

        List<double> numeros = new List<double>();

        for (int i = 0; i < cantidad; i++)
        {
            Console.Write("Ingresa el número " + (i + 1) + ": ");
            double valor = Convert.ToDouble(Console.ReadLine());
            numeros.Add(valor);
        }

        Console.WriteLine("\nLista ingresada: " + string.Join(", ", numeros));
        Console.WriteLine("Promedio = " + Promedio(numeros));

        Console.WriteLine("\nPresiona una tecla para salir...");
        Console.ReadKey();
    }
}
