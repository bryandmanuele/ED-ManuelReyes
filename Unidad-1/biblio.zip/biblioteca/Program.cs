﻿using biblioteca;
using System;

internal class Program
{

    static void Main()
    {
        Biblioteca biblioteca = new Biblioteca();

       
        Console.WriteLine(" ¿Cuántos libros deseas registrar?");
        int nLibros = int.Parse(Console.ReadLine());

        for (int i = 0; i < nLibros; i++)
        {
            Libro libro = new Libro();

            Console.WriteLine($"\nLibro {i + 1}:");
            Console.Write("Título: ");
            libro.Titulo = Console.ReadLine();

            Console.Write("Autor: ");
            libro.Autor = Console.ReadLine();

            Console.Write("ISBN: ");
            libro.ISBN = Console.ReadLine();

            biblioteca.AgregarLibro(libro);
        }


        Console.WriteLine("\n ¿Cuántos usuarios deseas registrar?");
        int nUsuarios = int.Parse(Console.ReadLine());

        for (int i = 0; i < nUsuarios; i++)
        {
            Autor usuario = new Autor();

            Console.WriteLine($"\nUsuario {i + 1}:");
            Console.Write("Nombre: ");
            usuario.Nombre = Console.ReadLine();

            Console.Write("ID: ");
            usuario.Id = int.Parse(Console.ReadLine());

            biblioteca.RegistrarUsuario(usuario);
        }

        biblioteca.MostrarLibros();
        biblioteca.MostrarUsuarios();

        Console.WriteLine("\nPRÉSTAMO");
        Console.Write("Ingresa ISBN del libro a prestar: ");
        string isbnPrestamo = Console.ReadLine();
        Console.Write("Ingresa ID del usuario: ");
        int idPrestamo = int.Parse(Console.ReadLine());
        biblioteca.PrestarLibro(isbnPrestamo, idPrestamo);

        Console.WriteLine("\n DEVOLUCIÓN ");
        Console.Write("Ingresa ISBN del libro a devolver: ");
        string isbnDevolucion = Console.ReadLine();
        Console.Write("Ingresa ID del usuario: ");
        int idDevolucion = int.Parse(Console.ReadLine());
        biblioteca.DevolverLibro(isbnDevolucion, idDevolucion);

        biblioteca.MostrarLibros();
        biblioteca.MostrarUsuarios();
        Console.WriteLine("\n Programa terminado. Presiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}