﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace biblioteca
{
	internal class Libro
	{
		private string strTitulo;

		public string Titulo
		{
			get { return strTitulo; }
			set { strTitulo = value; }
		}

		private string strAutor;

		public string Autor
		{
			get { return strAutor; }
			set { strAutor = value; }
		}
		private string strISBN;

		public string ISBN
		{
			get { return strISBN; }
			set { strISBN = value; }
		}

		private bool blnDisponible;

		public bool Disponible
		{
			get { return blnDisponible; }
			set { blnDisponible = value; }
		}
        public Libro()
        {
            Disponible = true; 
        }

        public void Prestar() => Disponible = false;
        public void Devolver() => Disponible = true;

        public override string ToString()
        {
            return $"{Titulo} - {Autor} (ISBN: {ISBN}) | {(Disponible ? "Disponible" : "Prestado")}";
        }
    }
}
