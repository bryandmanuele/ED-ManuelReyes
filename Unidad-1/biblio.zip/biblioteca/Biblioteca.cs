﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace biblioteca
{
    internal class Biblioteca
    {
        public List<Libro> Libros { get; set; } = new List<Libro>();
        public List<Autor> Usuarios { get; set; } = new List<Autor>();

        public void AgregarLibro(Libro libro) => Libros.Add(libro);
        public void RegistrarUsuario(Autor usuario) => Usuarios.Add(usuario);

        public void PrestarLibro(string isbn, int idUsuario)
        {
            Libro libro = Libros.Find(l => l.ISBN == isbn && l.Disponible);
            Autor usuario = Usuarios.Find(u => u.Id == idUsuario);

            if (libro != null && usuario != null)
            {
                libro.Prestar();
                usuario.PrestarLibro(libro);
                Console.WriteLine($" {usuario.Nombre} prestó el libro: {libro.Titulo}");
            }
            else
            {
                Console.WriteLine(" No se pudo realizar el préstamo.");
            }
        }

        public void DevolverLibro(string isbn, int idUsuario)
        {
            Libro libro = Libros.Find(l => l.ISBN == isbn);
            Autor usuario = Usuarios.Find(u => u.Id == idUsuario);

            if (libro != null && usuario != null && usuario.LibrosPrestados.Contains(libro))
            {
                libro.Devolver();
                usuario.DevolverLibro(libro);
                Console.WriteLine($" {usuario.Nombre} devolvió el libro: {libro.Titulo}");
            }
            else
            {
                Console.WriteLine(" No se pudo devolver el libro.");
            }
        }

        public void MostrarLibros()
        {
            Console.WriteLine("\n Libros en la biblioteca:");
            foreach (var libro in Libros) Console.WriteLine(libro);
        }

        public void MostrarUsuarios()
        {
            Console.WriteLine("\nUsuarios registrados:");
            foreach (var usuario in Usuarios) Console.WriteLine(usuario);
        }
    }
}
