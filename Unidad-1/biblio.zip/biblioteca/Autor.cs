﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace biblioteca
{
    internal class Autor
    {
		private string strNombre;

		public string Nombre
		{
			get { return strNombre; }
			set { strNombre = value; }
		}

		private int intId;

		public int Id
		{
			get { return intId; }
			set { intId = value; }
		}

        public List<Libro> LibrosPrestados { get; set; } = new List<Libro>();

        public Autor() { } // Constructor vacío

        public void PrestarLibro(Libro libro) => LibrosPrestados.Add(libro);
        public void DevolverLibro(Libro libro) => LibrosPrestados.Remove(libro);

        public override string ToString()
        {
            return $"{Nombre} (ID: {Id}) - Libros prestados: {LibrosPrestados.Count}";
        }
    }
}
