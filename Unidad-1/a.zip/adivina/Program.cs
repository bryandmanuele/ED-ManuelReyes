﻿using System;

class JuegoAdivina
{
    static void Main()
    {
        Random rnd = new Random();
        int secreto = rnd.Next(1, 101); 
        int intento;

        Console.WriteLine("Adivina el número (1 a 100):");

        do
        {
            intento = int.Parse(Console.ReadLine());

            if (intento < secreto) Console.WriteLine("Muy bajo");
            if (intento > secreto) Console.WriteLine("Muy alto");

        } while (intento != secreto);

        Console.WriteLine("¡Correcto!");
    }
}
