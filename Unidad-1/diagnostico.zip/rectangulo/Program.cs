﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rectangulo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rectangulo r = new Rectangulo(5, 10);
            Console.WriteLine(r);

            Cuadrado c = new Cuadrado(r);
            Console.WriteLine(c);
            Console.WriteLine("\nPresiona cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}
