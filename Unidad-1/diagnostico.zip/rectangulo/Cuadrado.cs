﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rectangulo
{
    internal class Cuadrado : Rectangulo
    {
        public Cuadrado(double lado) : base(lado, lado)
        {
        }

        public Cuadrado(Rectangulo r) : base(r.Ancho, r.Ancho)
        {
        }

    }
}
