﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rectangulo
{
    internal class Rectangulo
    {
		private double _dblAncho;

		public double Ancho
		{
			get { return _dblAncho; }
			set { _dblAncho = value; }
		}

		private double _dblAlto;

		public double Alto
		{
			get { return _dblAlto; }
			set { _dblAlto = value; }
		}

		public double Area()
		{
			return (_dblAlto * _dblAncho);
		}

		public double Perimetro()
		{
			return (_dblAlto*2) + (_dblAncho*2);
		}

		

		public Rectangulo(double dblAncho, double dblAlto)
        {
			_dblAncho = dblAncho;         
            _dblAlto = dblAlto;          
        }

		public override string ToString()
		{
			return "los datos del rectangulo son\n\nRectangulo:  " + "\nAncho: " + Ancho + "\nAlto: " + Alto + "\nArea: " + Area() + "\nPerimetro: " + Perimetro();
        }
    }
}
