﻿using System;

class ProgramaPrimo
{
    static void Main()
    {
        Console.WriteLine("Ingresa un número para verificar si es primo:");
        int numero = int.Parse(Console.ReadLine());
        bool esPrimo = true;

        if (numero < 2)
        {
            esPrimo = false;
        }
        else
        {
            for (int i = 2; i <= numero / 2; i++)
            {
                if (numero % i == 0)
                {
                    esPrimo = false;
                    break;
                }
            }
        }

        if (esPrimo)
            Console.WriteLine($"{numero} es primo.");
        else
            Console.WriteLine($"{numero} no es primo.");
    }
}
