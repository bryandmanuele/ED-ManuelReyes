﻿using System;

class Program
{
    static double Suma(double a, double b)
    {
        return a + b;
    }

    static double Resta(double a, double b)
    {
        return a - b;
    }

    static double Multiplicacion(double a, double b)
    {
        return a * b;
    }

    static double Division(double a, double b)
    {
        if (b != 0)
            return a / b;
        else
            throw new DivideByZeroException("Error: división entre cero.");
    }

    static void Main(string[] args)
    {
        int opcion;
        double num1, num2, resultado = 0;

        Console.WriteLine("Calculadora");
        Console.WriteLine("1. Suma");
        Console.WriteLine("2. Resta");
        Console.WriteLine("3. Multiplicación");
        Console.WriteLine("4. División");
        Console.Write("Elige una opción (1-4): ");
        opcion = Convert.ToInt32(Console.ReadLine());

        Console.Write("Ingresa el primer número: ");
        num1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Ingresa el segundo número: ");
        num2 = Convert.ToDouble(Console.ReadLine());

        switch (opcion)
        {
            case 1:
                resultado = Suma(num1, num2);
                break;
            case 2:
                resultado = Resta(num1, num2);
                break;
            case 3:
                resultado = Multiplicacion(num1, num2);
                break;
            case 4:
                try
                {
                    resultado = Division(num1, num2);
                }
                catch (DivideByZeroException e)
                {
                    Console.WriteLine(e.Message);
                    return;
                }
                break;
            default:
                Console.WriteLine("Opción no válida.");
                return;
        }

        Console.WriteLine("Resultado: " + resultado);

        Console.WriteLine("\nPresiona una tecla para salir...");
        Console.ReadKey();
    }
}
