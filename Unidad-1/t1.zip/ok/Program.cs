﻿using System;

class Programa
{
    static void Main()
    {
        Console.Write("Ingresa la temperatura en Celsius: ");
        double celsius = double.Parse(Console.ReadLine());
        double fahrenheit = (celsius * 9 / 5) + 32;
        Console.WriteLine("La temperatura en Fahrenheit es: " + fahrenheit);

        Console.WriteLine(); // salto de línea

        // === EJERCICIO 2: Calcular área de un círculo ===
        Console.Write("Ingresa el radio del círculo: ");
        double radio = double.Parse(Console.ReadLine());
        double area = Math.PI * radio * radio;
        Console.WriteLine("El área del círculo es: " + area);
    }
}
