﻿using libro;

class Program
{
    static void Main(string[] args)
    {
        Libro miLibro = new Libro();
        miLibro.Titulo = "El Principito";
        miLibro.Autor = "Antoine de Saint-Exupéry";

        miLibro.MostrarInfo();

        Console.WriteLine("\nPresiona una tecla para salir...");
        Console.ReadKey();
    }
}